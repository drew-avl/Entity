<?php

/**
 * Install hook.
 *
 * @return bool
 */
function plugin_n45context_install() {
    return true;
}

/**
 * Uninstall hook.
 *
 * @return bool
 */
function plugin_n45context_uninstall() {
    return true;
}
