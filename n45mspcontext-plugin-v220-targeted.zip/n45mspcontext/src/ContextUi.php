<?php

namespace GlpiPlugin\N45mspcontext;

use CommonDBTM;
use Ticket;

class ContextUi
{
    public static function preItilInfoSection(array $params): void
    {
        $item = $params['item'] ?? null;
        if (!$item instanceof Ticket) {
            return;
        }

        echo self::renderTicketSlot();
    }

    public static function preItemForm(array $params): void
    {
        $item = $params['item'] ?? null;
        $options = $params['options'] ?? [];

        if (!$item instanceof CommonDBTM) {
            return;
        }

        if ($item instanceof Ticket) {
            return;
        }

        if (!method_exists($item, 'isField') || !$item->isField('entities_id')) {
            return;
        }

        $colspan = (int) (($options['colspan'] ?? 2) * 2);
        if ($colspan <= 0) {
            $colspan = 4;
        }

        echo '<tr class="n45-mspcontext-row">';
        echo '<th colspan="' . $colspan . '">';
        echo '<div class="n45-mspcontext-generic-title">MSP Context</div>';
        echo '<div class="n45-mspcontext-generic-note" id="n45-mspcontext-generic-note">Entity will be promoted directly under this block when the selector is available.</div>';
        echo '</th>';
        echo '</tr>';
        echo '<tr id="n45-mspcontext-generic-anchor" class="n45-mspcontext-row">';
        echo '<td colspan="' . $colspan . '">';
        echo '<div id="n45-mspcontext-generic-slot" class="n45-mspcontext-generic-slot"></div>';
        echo '</td>';
        echo '</tr>';
        echo self::renderInlineBootstrap();
    }

    private static function renderTicketSlot(): string
    {
        return <<<HTML
<section class="accordion-item n45-mspcontext-ticket-section" aria-label="MSP context">
  <h2 class="accordion-header" id="n45-mspcontext-heading">
    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#n45-mspcontext-panel" aria-expanded="true" aria-controls="n45-mspcontext-panel">
      <i class="ti ti-building-community me-1"></i>
      <span class="item-title">MSP Context</span>
    </button>
  </h2>
  <div id="n45-mspcontext-panel" class="accordion-collapse collapse show" aria-labelledby="n45-mspcontext-heading">
    <div class="accordion-body">
      <div id="n45-mspcontext-ticket-note" class="n45-mspcontext-ticket-note">Entity and requester will be promoted here above Ticket.</div>
      <div id="n45-mspcontext-ticket-slot" class="n45-mspcontext-ticket-slot"></div>
    </div>
  </div>
</section>
HTML
        . self::renderInlineBootstrap();
    }

    private static function renderInlineBootstrap(): string
    {
        return <<<HTML
<script>
(function () {
  function run() {
    if (window.N45MSPContext && typeof window.N45MSPContext.boot === 'function') {
      window.N45MSPContext.boot();
    }
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run, { once: true });
  } else {
    run();
  }
  window.setTimeout(run, 50);
  window.setTimeout(run, 250);
})();
</script>
HTML;
    }
}
