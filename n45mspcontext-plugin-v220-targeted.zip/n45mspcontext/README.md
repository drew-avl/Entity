# N45 MSP Context for GLPI

## Purpose

Promotes the live **Entity** selector to the top of entity-aware native GLPI forms.

On the native **ticket** form, it promotes both live selectors to the top section above the standard **Ticket** heading:

- Entity
- Requester

The controls remain the original GLPI controls, so they stay interactive.

## Install

1. Extract the plugin folder into `glpi/plugins/n45mspcontext`
2. In GLPI go to **Setup -> Plugins**
3. Install **N45 MSP Context**
4. Enable it
5. Hard refresh the browser

## Tested target

Built against the current GLPI 10/11 ticket template structure where:

- `PRE_ITIL_INFO_SECTION` is rendered before the native ticket heading
- the ticket entity wrapper is rendered as `data-testid="form-field-entities_id"`
- the ticket requester wrapper is rendered as `data-testid="form-field-requester"`

## Notes

- Tickets: Entity + Requester are moved above the Ticket heading.
- Other native entity-aware forms: Entity is promoted under an MSP Context helper block.
- If a custom theme rewrites the native form markup heavily, selectors may need adjustment.
