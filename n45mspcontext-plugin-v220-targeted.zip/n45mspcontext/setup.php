<?php

define('PLUGIN_N45MSPCONTEXT_VERSION', '2.2.0');
define('PLUGIN_N45MSPCONTEXT_MIN_GLPI', '10.0.0');
define('PLUGIN_N45MSPCONTEXT_MAX_GLPI', '12.0.0');

use Glpi\Plugin\Hooks;
use GlpiPlugin\N45mspcontext\ContextUi;

function plugin_version_n45mspcontext()
{
    return [
        'name'         => 'N45 MSP Context',
        'version'      => PLUGIN_N45MSPCONTEXT_VERSION,
        'author'       => 'OpenAI',
        'license'      => 'GPLv2+',
        'homepage'     => '',
        'requirements' => [
            'glpi' => [
                'min' => PLUGIN_N45MSPCONTEXT_MIN_GLPI,
                'max' => PLUGIN_N45MSPCONTEXT_MAX_GLPI,
            ],
        ],
    ];
}

function plugin_init_n45mspcontext()
{
    global $PLUGIN_HOOKS;

    $PLUGIN_HOOKS['csrf_compliant']['n45mspcontext'] = true;

    spl_autoload_register(static function ($class) {
        $prefix = 'GlpiPlugin\\N45mspcontext\\';
        if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
            return;
        }

        $relative = substr($class, strlen($prefix));
        $path = __DIR__ . '/src/' . str_replace('\\', '/', $relative) . '.php';
        if (is_file($path)) {
            require_once $path;
        }
    });

    $PLUGIN_HOOKS[Hooks::ADD_JAVASCRIPT]['n45mspcontext'] = ['js/n45mspcontext.js'];
    $PLUGIN_HOOKS[Hooks::ADD_CSS]['n45mspcontext'] = 'css/n45mspcontext.css';

    $PLUGIN_HOOKS[Hooks::PRE_ITIL_INFO_SECTION]['n45mspcontext'] = [ContextUi::class, 'preItilInfoSection'];
    $PLUGIN_HOOKS[Hooks::PRE_ITEM_FORM]['n45mspcontext'] = [ContextUi::class, 'preItemForm'];
}

function plugin_n45mspcontext_install()
{
    return true;
}

function plugin_n45mspcontext_uninstall()
{
    return true;
}

function plugin_n45mspcontext_check_prerequisites()
{
    return version_compare(GLPI_VERSION, PLUGIN_N45MSPCONTEXT_MIN_GLPI, '>=')
        && version_compare(GLPI_VERSION, PLUGIN_N45MSPCONTEXT_MAX_GLPI, '<');
}

function plugin_n45mspcontext_check_config($verbose = false)
{
    return true;
}
