<?php
// Required plugin bootstrap file for GLPI.
