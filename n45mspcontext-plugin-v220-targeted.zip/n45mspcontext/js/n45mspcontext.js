(function () {
  if (window.N45MSPContext && window.N45MSPContext.__initialized) {
    return;
  }

  const api = {
    __initialized: true,
    observer: null,
    booted: false,
  };

  function $(selector, root) {
    return (root || document).querySelector(selector);
  }

  function first(selectors, root) {
    for (const selector of selectors) {
      const node = $(selector, root);
      if (node) return node;
    }
    return null;
  }

  function ticketPage() {
    return /\/front\/ticket\.form\.php(?:\?|$)/.test(location.pathname + location.search);
  }

  function markMoved(node) {
    if (node) {
      node.setAttribute('data-n45-moved', '1');
    }
  }

  function moved(node) {
    return !!(node && node.getAttribute('data-n45-moved') === '1');
  }

  function updateText(selector, text) {
    const node = $(selector);
    if (node) {
      node.textContent = text;
    }
  }

  function ensureTicketFieldSizing(wrapper) {
    if (!wrapper) return;
    wrapper.classList.add('n45-mspcontext-promoted');

    const inputContainer = $('.field-container', wrapper);
    if (inputContainer) {
      inputContainer.classList.add('col-12', 'col-xxl-12');
    }

    const label = $('.col-form-label', wrapper);
    if (label) {
      label.classList.remove('col-xxl-5');
      label.classList.add('col-12');
      label.classList.remove('text-xxl-end');
      label.classList.add('text-start');
    }
  }

  function entityWrapperTicket() {
    return first([
      '[data-testid="form-field-entities_id"]'
    ]);
  }

  function requesterWrapperTicket() {
    return first([
      '[data-testid="form-field-requester"]'
    ]);
  }

  function moveTicketFields() {
    const slot = $('#n45-mspcontext-ticket-slot');
    if (!slot) return false;

    let movedAny = false;
    const labels = [];

    const entity = entityWrapperTicket();
    if (entity && !moved(entity)) {
      slot.appendChild(entity);
      ensureTicketFieldSizing(entity);
      markMoved(entity);
      movedAny = true;
      labels.push('Entity');
    }

    const requester = requesterWrapperTicket();
    if (requester && !moved(requester)) {
      slot.appendChild(requester);
      ensureTicketFieldSizing(requester);
      markMoved(requester);
      movedAny = true;
      labels.push('Requester');
    }

    if (movedAny) {
      document.documentElement.classList.add('n45-mspcontext-ticket-applied');
      updateText('#n45-mspcontext-ticket-note', labels.join(' + ') + ' promoted above Ticket.');
      return true;
    }

    if (slot.children.length >= 2) {
      updateText('#n45-mspcontext-ticket-note', 'Entity + Requester promoted above Ticket.');
      return true;
    }

    updateText('#n45-mspcontext-ticket-note', 'Plugin active, but the current ticket field wrappers were not found yet.');
    return false;
  }

  function genericEntityWrapper() {
    return first([
      '[data-testid="form-field-entities_id"]',
      'select[name="entities_id"]',
      'input[name="entities_id"]'
    ]);
  }

  function closestFieldWrapper(node) {
    if (!node) return null;
    return node.closest('[data-testid="form-field-entities_id"]')
      || node.closest('.form-field')
      || node.closest('tr')
      || node.closest('.row')
      || node.parentElement
      || null;
  }

  function moveGenericEntity() {
    if (ticketPage()) return false;

    const slot = $('#n45-mspcontext-generic-slot');
    const anchor = $('#n45-mspcontext-generic-anchor');
    if (!slot || !anchor) return false;

    const raw = genericEntityWrapper();
    const wrapper = raw && raw.matches && raw.matches('[data-testid="form-field-entities_id"]') ? raw : closestFieldWrapper(raw);
    if (!wrapper) {
      updateText('#n45-mspcontext-generic-note', 'Plugin active, but no entity selector was found on this form.');
      return false;
    }

    if (moved(wrapper)) {
      return true;
    }

    if (wrapper.tagName === 'TR') {
      anchor.insertAdjacentElement('afterend', wrapper);
    } else {
      slot.appendChild(wrapper);
    }

    markMoved(wrapper);
    wrapper.classList.add('n45-mspcontext-promoted');
    document.documentElement.classList.add('n45-mspcontext-generic-applied');
    updateText('#n45-mspcontext-generic-note', 'Entity promoted under MSP Context.');
    return true;
  }

  function apply() {
    const ticketDone = moveTicketFields();
    const genericDone = moveGenericEntity();
    return ticketDone || genericDone;
  }

  api.boot = function boot() {
    apply();

    if (!api.booted) {
      api.booted = true;

      if (window.jQuery) {
        window.jQuery(function () {
          apply();
          window.jQuery('.glpi_tabs').on('tabsload', function () {
            apply();
          });
        });
      }

      api.observer = new MutationObserver(function () {
        apply();
      });

      api.observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
      });

      window.setTimeout(function () {
        if (api.observer) {
          api.observer.disconnect();
        }
      }, 15000);
    }

    return true;
  };

  window.N45MSPContext = api;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      api.boot();
    }, { once: true });
  } else {
    api.boot();
  }
})();
