# N45 Context Card

A lightweight GLPI plugin that promotes the most important customer-context fields to the top of native object forms.

## What it does

- **Tickets:** moves **Entity** and **Requester** into a top card labeled **Context / Customer**
- **Assets / configuration items:** moves **Entity** into a top card labeled **Context** when that field exists
- Leaves the rest of the native GLPI form intact

## Target pages

The plugin loads on native GLPI form pages such as:

- `front/ticket.form.php`
- `front/computer.form.php`
- `front/networkequipment.form.php`
- `front/monitor.form.php`
- `front/printer.form.php`
- similar native `*.form.php` pages

## Installation

1. Copy the `n45context` folder into `glpi/plugins/`
2. In GLPI, go to **Setup -> Plugins**
3. Install and enable **N45 Context Card**
4. Hard refresh the browser

## Notes

- The plugin uses DOM-based repositioning. It is intentionally small and non-destructive, but a major GLPI markup change could require selector updates.
- English and French label matching are included by default:
  - Entity / Entité
  - Requester / Requestor / Demandeur
  - Actors / Acteurs
- If your GLPI UI uses another language, extend the label arrays in `js/context-card.js`.

## Files

- `setup.php` - plugin bootstrap and asset loading
- `js/context-card.js` - DOM logic for promoting fields
- `css/context-card.css` - light styling for the top context card
