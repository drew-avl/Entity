<?php

define('PLUGIN_N45CONTEXT_VERSION', '1.2.0');

use Glpi\Plugin\Hooks;

function plugin_version_n45context() {
    return [
        'name'         => 'N45 Context Card',
        'version'      => PLUGIN_N45CONTEXT_VERSION,
        'author'       => 'OpenAI',
        'license'      => 'GPLv2+',
        'homepage'     => '',
        'requirements' => [
            'glpi' => [
                'min' => '10.0.0'
            ]
        ]
    ];
}

function plugin_init_n45context() {
    global $PLUGIN_HOOKS;

    $PLUGIN_HOOKS['csrf_compliant']['n45context'] = true;

    $request_uri = $_SERVER['REQUEST_URI'] ?? '';

    // Load only on native GLPI object form pages, for example:
    // /front/ticket.form.php
    // /front/computer.form.php
    // /front/networkequipment.form.php
    $is_native_form_page = preg_match('#/front/[^/]+\.form\.php(?:\?|$)#', $request_uri) === 1;

    if ($is_native_form_page) {
        $PLUGIN_HOOKS[Hooks::ADD_CSS]['n45context'] = 'css/context-card.css';
        $PLUGIN_HOOKS[Hooks::ADD_JAVASCRIPT]['n45context'] = [
            'js/context-card.js'
        ];
    }
}

function plugin_n45context_check_prerequisites() {
    return version_compare(GLPI_VERSION, '10.0.0', '>=');
}

function plugin_n45context_check_config($verbose = false) {
    return true;
}
