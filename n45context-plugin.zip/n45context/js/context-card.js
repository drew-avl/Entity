(() => {
  const isNativeFormPage = /\/front\/[^/]+\.form\.php(?:\?|$)/.test(
    location.pathname + location.search
  );

  if (!isNativeFormPage) return;

  const LABELS = {
    entity: ["entity", "entité"],
    requester: ["requester", "requestor", "demandeur"],
    actors: ["actors", "acteurs"]
  };

  const FIELD_WRAPPERS = [
    ".mb-3",
    ".form-group",
    ".row",
    ".form-field",
    ".field-container",
    ".input-group",
    ".d-flex",
    ".col-12",
    ".col",
    "tr",
    "li"
  ].join(", ");

  const norm = (s) => (s || "").replace(/\s+/g, " ").trim().toLowerCase();

  const includesAny = (text, values) => {
    const normalized = norm(text);
    return values.some((value) => normalized.includes(value));
  };

  const isVisible = (el) => {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden") return false;
    return el.getClientRects().length > 0;
  };

  function getPageType() {
    return location.pathname.toLowerCase().includes("/ticket.form.php")
      ? "ticket"
      : "generic";
  }

  function findMainForm() {
    return document.querySelector("form");
  }

  function findTopInsertionPoint(form) {
    if (!form) return null;

    return (
      form.querySelector(".tab_cadre_fixe") ||
      form.querySelector(".container-fluid") ||
      form.querySelector(".row") ||
      form
    );
  }

  function findSectionByHeading(matchers) {
    const candidates = [
      ...document.querySelectorAll("section, .card, .accordion-item, fieldset, .tab_cadre_fixe")
    ];

    for (const candidate of candidates) {
      const heading = candidate.querySelector(
        "h1,h2,h3,h4,h5,h6,.card-title,.accordion-header,legend"
      );

      if (heading && includesAny(heading.textContent, matchers)) {
        return candidate;
      }
    }

    return null;
  }

  function findLabelCandidates(scope) {
    return [
      ...scope.querySelectorAll(
        "label, .form-label, .control-label, .col-form-label, th, legend, .fw-bold, td b"
      )
    ].filter(isVisible);
  }

  function findFieldBlockByLabel(scope, matchers) {
    const labels = findLabelCandidates(scope);

    for (const label of labels) {
      if (!includesAny(label.textContent, matchers)) continue;

      const explicitBlock = label.closest(FIELD_WRAPPERS);
      if (explicitBlock) return explicitBlock;

      const row = label.closest("tr");
      if (row) return row;

      const parent = label.parentElement;
      if (parent && isVisible(parent)) return parent;
    }

    return null;
  }

  function buildContextCard(titleText = "Context") {
    const wrapper = document.createElement("div");
    wrapper.className = "card mb-3 n45-context-card";
    wrapper.id = "n45-context-card";

    const header = document.createElement("div");
    header.className = "card-header";

    const title = document.createElement("h3");
    title.className = "card-title mb-0";
    title.textContent = titleText;

    const body = document.createElement("div");
    body.className = "card-body";
    body.id = "n45-context-card-body";

    header.appendChild(title);
    wrapper.appendChild(header);
    wrapper.appendChild(body);

    return wrapper;
  }

  function getOrCreateContextCard(form, titleText) {
    let card = document.getElementById("n45-context-card");
    if (card) return card;

    card = buildContextCard(titleText);
    const insertionPoint = findTopInsertionPoint(form);
    if (!insertionPoint) return null;

    if (insertionPoint === form) {
      form.prepend(card);
    } else {
      insertionPoint.prepend(card);
    }

    return card;
  }

  function getOrCreateTableBody(cardBody) {
    let table = cardBody.querySelector(".n45-context-table");
    if (!table) {
      table = document.createElement("table");
      table.className = "tab_cadre_fixe n45-context-table";
      table.style.width = "100%";
      table.style.marginBottom = "0";

      const tbody = document.createElement("tbody");
      table.appendChild(tbody);
      cardBody.appendChild(table);
      return tbody;
    }

    return table.querySelector("tbody");
  }

  function getCurrentMovedFieldKeys() {
    return Array.from(document.querySelectorAll(".n45-context-moved[data-n45-field-key]"))
      .map((el) => el.dataset.n45FieldKey)
      .filter(Boolean);
  }

  function hasMovedField(fieldKey) {
    return getCurrentMovedFieldKeys().includes(fieldKey);
  }

  function moveBlockIntoCard(block, cardBody, fieldKey) {
    if (!block || !cardBody || !fieldKey) return false;
    if (block.classList?.contains("n45-context-moved") || hasMovedField(fieldKey)) return false;

    block.classList?.add("n45-context-moved");
    block.dataset.n45FieldKey = fieldKey;

    if (block.tagName === "TR") {
      const tbody = getOrCreateTableBody(cardBody);
      tbody.appendChild(block);
    } else {
      cardBody.appendChild(block);
    }

    return true;
  }

  function addHint(cardBody, pageType, movedEntity, movedRequester) {
    if (!cardBody) return;

    const existingHint = cardBody.querySelector(".n45-context-hint");
    if (existingHint) existingHint.remove();

    let text = "";

    if (pageType === "ticket" && movedEntity && movedRequester) {
      text = "Select entity and requester first so the rest of the form resolves in the correct customer context.";
    } else if (pageType === "ticket" && movedRequester) {
      text = "Select the requester first so entity and downstream ticket behavior resolve in the correct customer context.";
    } else if (movedEntity) {
      text = "Select the entity first so this object is created in the correct customer context.";
    }

    if (!text) return;

    const hint = document.createElement("div");
    hint.className = "form-text n45-context-hint";
    hint.textContent = text;
    cardBody.appendChild(hint);
  }

  function maybeHideEmptyActorsSection(actorsSection) {
    if (!actorsSection) return;

    const meaningfulControls = actorsSection.querySelectorAll(
      "input, select, textarea, .select2-container, .dropdown, button"
    );

    if (meaningfulControls.length === 0) {
      actorsSection.classList.add("n45-empty-actors-section");
    }
  }

  function cleanupIfEmpty(card) {
    if (!card) return false;
    const body = card.querySelector("#n45-context-card-body");
    if (!body) {
      card.remove();
      return false;
    }

    const meaningfulChildren = Array.from(body.children).filter(
      (child) => !child.classList.contains("n45-context-hint")
    );

    if (meaningfulChildren.length === 0) {
      card.remove();
      return false;
    }

    return true;
  }

  function applyContextCard() {
    const form = findMainForm();
    if (!form) return false;

    const pageType = getPageType();
    const titleText = pageType === "ticket" ? "Context / Customer" : "Context";
    const card = getOrCreateContextCard(form, titleText);
    if (!card) return false;

    const cardBody = card.querySelector("#n45-context-card-body");
    if (!cardBody) return false;

    let movedEntity = false;
    let movedRequester = false;

    const entityBlock = findFieldBlockByLabel(form, LABELS.entity);
    if (entityBlock && !entityBlock.closest("#n45-context-card")) {
      movedEntity = moveBlockIntoCard(entityBlock, cardBody, "entity");
    }

    if (pageType === "ticket") {
      const actorsSection = findSectionByHeading(LABELS.actors);
      const requesterBlock =
        (actorsSection && findFieldBlockByLabel(actorsSection, LABELS.requester)) ||
        findFieldBlockByLabel(form, LABELS.requester);

      if (requesterBlock && !requesterBlock.closest("#n45-context-card")) {
        movedRequester = moveBlockIntoCard(requesterBlock, cardBody, "requester");
        maybeHideEmptyActorsSection(actorsSection);
      }
    }

    const currentMoved = getCurrentMovedFieldKeys();
    addHint(
      cardBody,
      pageType,
      currentMoved.includes("entity"),
      currentMoved.includes("requester")
    );

    if (!cleanupIfEmpty(card)) return false;

    card.classList.add("n45-context-card--active");
    document.documentElement.classList.add("n45-context-card-applied");
    return movedEntity || movedRequester || currentMoved.length > 0;
  }

  let applied = false;

  function tryApply() {
    const result = applyContextCard();
    if (result) applied = true;
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", tryApply, { once: true });
  } else {
    tryApply();
  }

  window.addEventListener("load", tryApply, { once: true });

  if (window.jQuery) {
    window.jQuery(() => {
      tryApply();
      window.jQuery(".glpi_tabs").on("tabsload", () => {
        applied = false;
        tryApply();
      });
    });
  }

  const observer = new MutationObserver(() => {
    if (!applied) tryApply();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });

  setTimeout(() => observer.disconnect(), 12000);
})();
