(function () {
  const html = document.documentElement;

  function safeRun(fn) {
    try {
      fn();
    } catch (error) {
      console.error('N45 MSP Context error:', error);
    }
  }

  function ticketPageActive() {
    return /\/front\/ticket\.form\.php(?:\?|$)/.test(location.pathname + location.search);
  }

  function markMoved(node) {
    if (node && node.dataset) {
      node.dataset.n45Moved = '1';
    }
  }

  function alreadyMoved(node) {
    return !!(node && node.dataset && node.dataset.n45Moved === '1');
  }

  function normalize(text) {
    return (text || '').replace(/\s+/g, ' ').trim().toLowerCase();
  }

  function visible(node) {
    return !!(node && node.getClientRects && node.getClientRects().length);
  }

  function firstExisting(selectors) {
    for (const selector of selectors) {
      const node = document.querySelector(selector);
      if (node) return node;
    }
    return null;
  }

  function closestFieldWrapper(node) {
    if (!node) return null;
    return node.closest('[data-testid^="form-field-"]')
      || node.closest('.form-field')
      || node.closest('.mb-3')
      || node.closest('.row')
      || node.closest('tr')
      || node.closest('.input-group')
      || node.closest('.d-flex')
      || node.parentElement
      || null;
  }

  function findEntityFieldTicket() {
    return firstExisting([
      '[data-testid="form-field-entities_id"]',
      'select[name="_users_id_requester_notif\[entities_id\]"]',
      'select[name="entities_id"]',
      'input[name="entities_id"]'
    ]);
  }

  function findRequesterFieldTicket() {
    return firstExisting([
      '[data-testid="form-field-requester"]',
      'select[name="_users_id_requester"]',
      'select[name="users_id_requester"]',
      'select[name="requester_id"]',
      'input[name="_users_id_requester"]',
      'input[name="users_id_requester"]'
    ]);
  }

  function findGenericEntityWrapper() {
    const input = firstExisting([
      'select[name="entities_id"]',
      'input[name="entities_id"]',
      '[data-testid="form-field-entities_id"] select',
      '[data-testid="form-field-entities_id"] input'
    ]);

    if (!input) return null;
    return closestFieldWrapper(input);
  }

  function updateNote(id, text) {
    const note = document.getElementById(id) || document.querySelector(id);
    if (note) note.textContent = text;
  }

  function moveTicketFields() {
    if (!ticketPageActive()) return false;

    const slot = document.getElementById('n45-context-itil-slot');
    const fieldsWrap = document.getElementById('n45-context-itil-fields');
    if (!slot || !fieldsWrap) return false;

    let movedAny = false;
    let movedLabels = [];

    const entityCandidate = findEntityFieldTicket();
    const entityWrapper = entityCandidate && entityCandidate.matches('[data-testid="form-field-entities_id"]')
      ? entityCandidate
      : closestFieldWrapper(entityCandidate);

    if (entityWrapper && !alreadyMoved(entityWrapper)) {
      fieldsWrap.appendChild(entityWrapper);
      markMoved(entityWrapper);
      entityWrapper.classList.add('n45-promoted-field');
      movedAny = true;
      movedLabels.push('Entity');
    }

    const requesterCandidate = findRequesterFieldTicket();
    const requesterWrapper = requesterCandidate && requesterCandidate.matches('[data-testid="form-field-requester"]')
      ? requesterCandidate
      : closestFieldWrapper(requesterCandidate);

    if (requesterWrapper && !alreadyMoved(requesterWrapper)) {
      fieldsWrap.appendChild(requesterWrapper);
      markMoved(requesterWrapper);
      requesterWrapper.classList.add('n45-promoted-field');
      movedAny = true;
      movedLabels.push('Requester');
    }

    if (movedAny) {
      html.classList.add('n45-ticket-context-applied');
      updateNote('n45-context-itil-note', movedLabels.join(' + ') + ' promoted to the top of the right panel.');
      return true;
    }

    updateNote('n45-context-itil-note', 'Plugin active, but ticket field selectors were not matched on this page render.');
    return false;
  }

  function moveGenericEntityField() {
    if (ticketPageActive()) return false;

    const anchorRow = document.getElementById('n45-context-item-anchor');
    const slot = document.getElementById('n45-context-item-slot');
    if (!anchorRow || !slot) return false;

    const wrapper = findGenericEntityWrapper();
    if (!wrapper) {
      updateNote('#n45-context-item-slot .n45-context-note', 'Plugin active, but no movable entity field was detected on this form.');
      return false;
    }

    if (alreadyMoved(wrapper)) {
      return true;
    }

    if (wrapper.tagName === 'TR') {
      anchorRow.insertAdjacentElement('afterend', wrapper);
    } else {
      slot.appendChild(wrapper);
    }

    markMoved(wrapper);
    wrapper.classList.add('n45-promoted-field');
    html.classList.add('n45-generic-context-applied');
    updateNote('#n45-context-item-slot .n45-context-note', 'Entity promoted directly below this MSP context block.');
    return true;
  }

  function applyContextTweaks() {
    const ticketDone = moveTicketFields();
    const genericDone = moveGenericEntityField();
    return ticketDone || genericDone;
  }

  function bind() {
    safeRun(applyContextTweaks);

    if (window.jQuery) {
      window.jQuery(function () {
        safeRun(applyContextTweaks);
        window.jQuery('.glpi_tabs').on('tabsload', function () {
          safeRun(applyContextTweaks);
        });
      });
    }

    const observer = new MutationObserver(function () {
      safeRun(applyContextTweaks);
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
    });

    window.setTimeout(function () {
      observer.disconnect();
    }, 15000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind);
  } else {
    bind();
  }
})();
