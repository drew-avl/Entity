<?php

namespace GlpiPlugin\N45mspcontext;

use Glpi\Application\View\TemplateRenderer;
use Ticket;

class ContextUi
{
    public static function preItilSection(array $params): void
    {
        $item = $params['item'] ?? null;
        if (!$item || $item::class !== Ticket::class) {
            return;
        }

        echo TemplateRenderer::getInstance()->renderFromStringTemplate(<<<'TWIG'
<section class="accordion-item n45-context-accordion" aria-label="MSP context">
   <h2 class="accordion-header" id="n45-context-heading">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#n45-context-panel" aria-expanded="true" aria-controls="n45-context-panel">
         <i class="ti ti-building-community me-1"></i>
         <span class="item-title">MSP Context</span>
      </button>
   </h2>
   <div id="n45-context-panel" class="accordion-collapse collapse show" aria-labelledby="n45-context-heading">
      <div class="accordion-body">
         <div id="n45-context-itil-slot" class="n45-context-slot" data-n45-page="ticket">
            <div class="n45-context-note" id="n45-context-itil-note">
               Plugin active. Entity and requester will be promoted here when matching fields are detected.
            </div>
            <div class="n45-context-fields" id="n45-context-itil-fields"></div>
         </div>
      </div>
   </div>
</section>
TWIG, []);
    }

    public static function preItemForm(array $params): void
    {
        $item = $params['item'] ?? null;
        $options = $params['options'] ?? [];
        if (!$item) {
            return;
        }

        if ($item::class === Ticket::class) {
            return;
        }

        if (!method_exists($item, 'isField') || !$item->isField('entities_id')) {
            return;
        }

        $colspan = (int) (($options['colspan'] ?? 2) * 2);
        if ($colspan <= 0) {
            $colspan = 4;
        }

        $out  = '<tr class="n45-context-row">';
        $out .= '<th colspan="' . $colspan . '">';
        $out .= '<div class="n45-context-header">MSP Context</div>';
        $out .= '<div class="n45-context-subheader">Plugin active. Verify the customer entity before creating or editing this record.</div>';
        $out .= '</th>';
        $out .= '</tr>';

        $out .= '<tr id="n45-context-item-anchor" class="n45-context-row">';
        $out .= '<td colspan="' . $colspan . '">';
        $out .= '<div id="n45-context-item-slot" class="n45-context-slot" data-n45-page="generic-item">';
        $out .= '<div class="n45-context-note">The entity selector will be moved directly under this block when the page markup supports it.</div>';
        $out .= '</div>';
        $out .= '</td>';
        $out .= '</tr>';

        echo $out;
    }
}
