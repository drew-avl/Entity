# N45 MSP Context

Test build `2.1.0`.

## Goal

Promote MSP-critical context fields to the top of GLPI forms:

- **Tickets**: Entity + Requester
- **Assets / configuration items**: Entity

## Installation

1. Extract `n45mspcontext` into `glpi/plugins/`
2. In GLPI, go to **Setup -> Plugins**
3. Install and enable **N45 MSP Context**
4. Hard refresh the browser

## Testing notes

This build intentionally leaves a visible **MSP Context** block in the UI even if field movement fails.
That makes it easier to confirm whether the plugin is loading at all.

## Expected pages to test

- `/front/ticket.form.php`
- `/front/computer.form.php`
- `/front/networkequipment.form.php`
- `/front/printer.form.php`

## Rollback

Disable the plugin in **Setup -> Plugins** and hard refresh.
