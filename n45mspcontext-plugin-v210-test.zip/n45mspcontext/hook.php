<?php

function plugin_n45mspcontext_install()
{
    return true;
}

function plugin_n45mspcontext_uninstall()
{
    return true;
}
